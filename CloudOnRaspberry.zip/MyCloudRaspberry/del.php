<?php



//rmdir('Customers/luxena');
//rmdir('Img_Customers/prova');

unlink('Customers/luxena/testing/f.PNG');
unlink('Customers/luxena/testing/i.png');

rmdir('Customers/luxena/testing');

?>
