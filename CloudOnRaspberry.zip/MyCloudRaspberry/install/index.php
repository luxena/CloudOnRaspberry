<?php

require_once "../php/creaTable.php";

?>
